package com.h4ll0.pyide

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class DrawCmd {
    data class Fill(val color: Long) : DrawCmd()
    data class Rect(val x: Double, val y: Double, val w: Double, val h: Double, val color: Long) : DrawCmd()
    data class Circ(val x: Double, val y: Double, val r: Double, val color: Long) : DrawCmd()
    data class Line(val x1: Double, val y1: Double, val x2: Double, val y2: Double, val color: Long, val width: Double) : DrawCmd()
    data class Txt(val x: Double, val y: Double, val s: String, val color: Long, val size: Double) : DrawCmd()
}

/** Dipanggil dari Python lewat: from com.h4ll0.pyide import CanvasBridge as canvas */
object CanvasBridge {
    private val _frame = MutableStateFlow<List<DrawCmd>>(emptyList())
    val frame: StateFlow<List<DrawCmd>> = _frame
    private val buf = mutableListOf<DrawCmd>()

    @Volatile var stopRequested = false
    const val WIDTH = 400.0
    const val HEIGHT = 500.0

    private fun checkStop(): Boolean = stopRequested

    @JvmStatic fun width() = WIDTH
    @JvmStatic fun height() = HEIGHT

    @JvmStatic fun fill(color: Long) { if (checkStop()) return; buf.clear(); buf.add(DrawCmd.Fill(color)); _frame.value = buf.toList() }
    @JvmStatic fun rect(x: Double, y: Double, w: Double, h: Double, color: Long) { if (checkStop()) return; buf.add(DrawCmd.Rect(x, y, w, h, color)); _frame.value = buf.toList() }
    @JvmStatic fun circle(x: Double, y: Double, r: Double, color: Long) { if (checkStop()) return; buf.add(DrawCmd.Circ(x, y, r, color)); _frame.value = buf.toList() }
    @JvmStatic fun line(x1: Double, y1: Double, x2: Double, y2: Double, color: Long, width: Double) { if (checkStop()) return; buf.add(DrawCmd.Line(x1, y1, x2, y2, color, width)); _frame.value = buf.toList() }
    @JvmStatic fun text(x: Double, y: Double, s: String, color: Long, size: Double) { if (checkStop()) return; buf.add(DrawCmd.Txt(x, y, s, color, size)); _frame.value = buf.toList() }
    @JvmStatic fun sleep(seconds: Double) { if (checkStop()) return; Thread.sleep((seconds * 1000).toLong().coerceAtLeast(0)) }

    fun reset() { stopRequested = false; buf.clear(); _frame.value = emptyList() }
}
