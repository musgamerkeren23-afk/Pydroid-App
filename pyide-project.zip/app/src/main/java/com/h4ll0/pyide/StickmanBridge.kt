package com.h4ll0.pyide

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Dipanggil dari Python lewat: from com.h4ll0.pyide import StickmanBridge */
object StickmanBridge {
    private val _pose = MutableStateFlow(
        mapOf("head" to 0f, "torso" to 0f, "arm_left" to 20f, "arm_right" to -20f,
              "leg_left" to 10f, "leg_right" to -10f, "x" to 0f, "y" to 0f)
    )
    val pose: StateFlow<Map<String, Float>> = _pose

    @Volatile var stopRequested = false

    @JvmStatic
    fun set(part: String, deg: Double) {
        if (stopRequested) return
        val m = _pose.value.toMutableMap(); m[part] = deg.toFloat(); _pose.value = m
    }

    @JvmStatic
    fun move(dx: Double, dy: Double) {
        if (stopRequested) return
        val m = _pose.value.toMutableMap()
        m["x"] = (m["x"] ?: 0f) + dx.toFloat(); m["y"] = (m["y"] ?: 0f) + dy.toFloat()
        _pose.value = m
    }

    @JvmStatic
    fun sleep(seconds: Double) {
        if (stopRequested) return
        Thread.sleep((seconds * 1000).toLong().coerceAtLeast(0))
    }

    fun reset() {
        stopRequested = false
        _pose.value = mapOf("head" to 0f, "torso" to 0f, "arm_left" to 20f, "arm_right" to -20f,
            "leg_left" to 10f, "leg_right" to -10f, "x" to 0f, "y" to 0f)
    }
}
