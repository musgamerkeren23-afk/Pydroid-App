package com.h4ll0.pyide

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color as GColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chaquo.python.PyException
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Red = Color(0xFFE0262E)
private const val DEFAULT_CODE = "print(\"Halo dari Ech0 PyIDE!\")\n\nfor i in range(5):\n    print(\"Angka:\", i)\n"
private const val STICK_CODE = """from com.h4ll0.pyide import StickmanBridge as stick
import math, time

for i in range(200):
    a = math.sin(i / 10) * 40
    stick.set("arm_left", 20 + a)
    stick.set("arm_right", -20 - a)
    stick.set("leg_left", 10 - a / 2)
    stick.set("leg_right", -10 + a / 2)
    stick.set("head", a / 6)
    stick.sleep(0.05)
"""

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Color(0xFF0D0A0A), surface = Color(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

fun runPython(code: String): String {
    val py = Python.getInstance()
    val sys = py.getModule("sys")
    val io = py.getModule("io")
    val buf = io.callAttr("StringIO")
    val oldOut = sys.get("stdout"); val oldErr = sys.get("stderr")
    sys.put("stdout", buf); sys.put("stderr", buf)
    return try {
        val builtins = py.getBuiltins()
        builtins.callAttr("exec", code)
        buf.callAttr("getvalue").toString()
    } catch (e: PyException) {
        buf.callAttr("getvalue").toString() + "\n" + (e.message ?: "Error")
    } finally {
        sys.put("stdout", oldOut); sys.put("stderr", oldErr)
    }
}

@Composable
fun App() {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PyIDE", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Red, modifier = Modifier.weight(1f))
        }
        ScrollableTabRow(selectedTabIndex = tab) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Kode") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Stickman") })
            Tab(tab == 2, { tab = 2 }, text = { Text("Canvas") })
            Tab(tab == 3, { tab = 3 }, text = { Text("Tutorial") })
        }
        when (tab) { 0 -> CodeTab(); 1 -> StickmanTab(); 2 -> CanvasTab(); else -> TutorialTab() }
    }
}

@Composable
fun CodeTab() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { c.getSharedPreferences("pyide", Context.MODE_PRIVATE) }
    var code by remember { mutableStateOf(prefs.getString("code", DEFAULT_CODE) ?: DEFAULT_CODE) }
    var output by remember { mutableStateOf("Tap \"Jalankan\" buat lihat hasilnya di sini.") }
    var running by remember { mutableStateOf(false) }
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp)

    fun run() {
        running = true
        prefs.edit().putString("code", code).apply()
        scope.launch {
            val r = withContext(Dispatchers.Default) { runPython(code) }
            output = r.ifBlank { "(tidak ada output)" }
            running = false
        }
    }

    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Button(onClick = { run() }, enabled = !running) { Text(if (running) "Jalan..." else "▶ Jalankan") }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = code, onValueChange = { code = it },
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = mono,
            label = { Text("Kode Python") },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrect = false)
        )
        Spacer(Modifier.height(8.dp))
        Text("Output", fontWeight = FontWeight.Bold, color = Color.Gray)
        Card(Modifier.fillMaxWidth().weight(0.6f)) {
            Text(output, Modifier.padding(10.dp).verticalScroll(rememberScrollState()), style = mono)
        }
    }
}

@Composable
fun StickmanTab() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { c.getSharedPreferences("pyide", Context.MODE_PRIVATE) }
    var code by remember { mutableStateOf(prefs.getString("stick_code", STICK_CODE) ?: STICK_CODE) }
    var output by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
    val pose by StickmanBridge.pose.collectAsStateWithLifecycle()

    fun run() {
        StickmanBridge.reset()
        running = true
        prefs.edit().putString("stick_code", code).apply()
        scope.launch {
            val r = withContext(Dispatchers.Default) { runPython(code) }
            output = r
            running = false
        }
    }
    fun stop() { StickmanBridge.stopRequested = true; running = false }

    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Text("Gerakin stickman pakai: stick.set(\"bagian\", derajat) lalu stick.sleep(detik)", color = Color.Gray, fontSize = 12.sp)
        Card(Modifier.fillMaxWidth().height(220.dp).padding(vertical = 8.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val cx = size.width / 2 + (pose["x"] ?: 0f)
                val cy = size.height / 2 + (pose["y"] ?: 0f)
                val s = size.minDimension / 6
                fun rad(d: Float) = Math.toRadians(d.toDouble())
                fun tip(ox: Float, oy: Float, len: Float, deg: Float) = Offset(
                    (ox + len * kotlin.math.sin(rad(deg))).toFloat(),
                    (oy + len * kotlin.math.cos(rad(deg))).toFloat()
                )
                val stroke = Stroke(width = 8f, cap = StrokeCap.Round)
                val head = Offset(cx + (pose["head"] ?: 0f), cy - s * 2.2f)
                val neck = Offset(cx, cy - s * 1.6f)
                val hip = Offset(cx, cy)
                drawCircle(Color.White, radius = s * 0.4f, center = head, style = stroke)
                drawLine(Color.White, neck, hip, strokeWidth = 8f, cap = StrokeCap.Round)
                drawLine(Color.White, neck, tip(neck.x, neck.y, s, pose["arm_left"] ?: 0f), strokeWidth = 8f, cap = StrokeCap.Round)
                drawLine(Color.White, neck, tip(neck.x, neck.y, s, 180f - (pose["arm_right"] ?: 0f) * -1f + 0f).let {
                    tip(neck.x, neck.y, s, (pose["arm_right"] ?: 0f))
                }, strokeWidth = 8f, cap = StrokeCap.Round)
                drawLine(Color.White, hip, tip(hip.x, hip.y, s, 180f - (pose["leg_left"] ?: 0f)), strokeWidth = 8f, cap = StrokeCap.Round)
                drawLine(Color.White, hip, tip(hip.x, hip.y, s, 180f - (pose["leg_right"] ?: 0f)), strokeWidth = 8f, cap = StrokeCap.Round)
            }
        }
        Row {
            Button(onClick = { run() }, enabled = !running) { Text(if (running) "Jalan..." else "▶ Jalankan") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { stop() }, enabled = running) { Text("Stop") }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = code, onValueChange = { code = it },
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = mono, label = { Text("Kode Python (gerakin stickman)") },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrect = false)
        )
        if (output.isNotBlank()) Text(output, color = Color(0xFFFF7B7B), style = mono, modifier = Modifier.padding(top = 4.dp))
    }
}


@Composable
fun CanvasTab() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { c.getSharedPreferences("pyide", Context.MODE_PRIVATE) }
    var code by remember { mutableStateOf(prefs.getString("canvas_code", CANVAS_CODE) ?: CANVAS_CODE) }
    var output by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
    val frame by CanvasBridge.frame.collectAsStateWithLifecycle()

    fun run() {
        CanvasBridge.reset(); running = true
        prefs.edit().putString("canvas_code", code).apply()
        scope.launch {
            val r = withContext(Dispatchers.Default) { runPython(code) }
            output = r; running = false
        }
    }
    fun stop() { CanvasBridge.stopRequested = true; running = false }

    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Text("Gaya pygame: canvas.fill() / canvas.rect() / canvas.circle() / canvas.sleep()", color = Color.Gray, fontSize = 12.sp)
        Card(Modifier.fillMaxWidth().height(260.dp).padding(vertical = 8.dp)) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val sx = size.width / CanvasBridge.WIDTH.toFloat()
                val sy = size.height / CanvasBridge.HEIGHT.toFloat()
                frame.forEach { cmd ->
                    when (cmd) {
                        is DrawCmd.Fill -> drawRect(GColor(cmd.color), size = size)
                        is DrawCmd.Rect -> drawRect(GColor(cmd.color),
                            topLeft = androidx.compose.ui.geometry.Offset((cmd.x * sx).toFloat(), (cmd.y * sy).toFloat()),
                            size = androidx.compose.ui.geometry.Size((cmd.w * sx).toFloat(), (cmd.h * sy).toFloat()))
                        is DrawCmd.Circ -> drawCircle(GColor(cmd.color), radius = (cmd.r * sx).toFloat(),
                            center = androidx.compose.ui.geometry.Offset((cmd.x * sx).toFloat(), (cmd.y * sy).toFloat()))
                        is DrawCmd.Line -> drawLine(GColor(cmd.color),
                            androidx.compose.ui.geometry.Offset((cmd.x1 * sx).toFloat(), (cmd.y1 * sy).toFloat()),
                            androidx.compose.ui.geometry.Offset((cmd.x2 * sx).toFloat(), (cmd.y2 * sy).toFloat()),
                            strokeWidth = cmd.width.toFloat())
                        is DrawCmd.Txt -> drawContext.canvas.nativeCanvas.drawText(
                            cmd.s, (cmd.x * sx), (cmd.y * sy),
                            android.graphics.Paint().apply { color = cmd.color.toInt(); textSize = cmd.size.toFloat() * sy }
                        )
                    }
                }
            }
        }
        Row {
            Button(onClick = { run() }, enabled = !running) { Text(if (running) "Jalan..." else "▶ Jalankan") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { stop() }, enabled = running) { Text("Stop") }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = code, onValueChange = { code = it },
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = mono, label = { Text("Kode Python (canvas)") },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrect = false)
        )
        if (output.isNotBlank()) Text(output, color = Color(0xFFFF7B7B), style = mono, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun TutorialTab() {
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text(TUTORIAL_TEXT, style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp))
    }
}
